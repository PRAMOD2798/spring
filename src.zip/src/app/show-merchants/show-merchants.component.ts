import { Component, OnInit } from '@angular/core';
import { Merchant } from '../Merchant';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-show-merchants',
  templateUrl: './show-merchants.component.html',
  styleUrls: ['./show-merchants.component.css']
})
export class ShowMerchantsComponent  {
  

  merchant:Merchant[];
  status:boolean=false;
  merch:Merchant;
  

  constructor( private httpClientService:AdminServiceService) { }

  onSubmit() {
    
    // this.httpClientService.showMerchants().subscribe(
    //   data =>{this.merchant = data;}
    //  );
     this.status=true;
  }

}
