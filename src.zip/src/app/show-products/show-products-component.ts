import { Component } from '@angular/core';
import { Product } from 'src/app/product';
import { AdminServiceService } from 'src/app/admin-service.service';

@Component({
    selector: 'show-products',
    templateUrl: './show-products-component.html',
    
  })
  export class ShowProductComponent{

    product:Product[];
    
    constructor(public productService:AdminServiceService) { }
  
    ngOnInit() {
    }
  
  
    showProducts(){
      this.productService.showProducts().subscribe(response=>this.handleSuccessfulResponse(response));
    }
  
    handleSuccessfulResponse(response){
      //this.status=true;
      this.product=response;
      console.log(this.productService);
    }
  }
  

  