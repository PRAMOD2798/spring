import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DispatchedProductsComponent } from './dispatched-products.component';

describe('DispatchedProductsComponent', () => {
  let component: DispatchedProductsComponent;
  let fixture: ComponentFixture<DispatchedProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DispatchedProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DispatchedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
