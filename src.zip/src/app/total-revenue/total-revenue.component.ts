import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-total-revenue',
  templateUrl: './total-revenue.component.html',
  styleUrls: ['./total-revenue.component.css']
})
export class TotalRevenueComponent implements OnInit {

  revenue:number;
  constructor(private httpClientService:AdminServiceService) { }

  ngOnInit() {
    this.httpClientService.totalRevenue().subscribe(
      data=>{
        this.revenue=data;
      }
    )
  }

}
