import { Product } from './product';
import { Address } from './address';
import { CartItems } from './cartItems';
import { Order } from './order';
import { Gender } from './Gender';

export class Customer {

    customerId:number;
    authToken:string;
    customerName:string;
    addresses:Address;
    email:string;
    mobileNo:string;
    gender:Gender;
    wishItems:Product;
    cartItems:CartItems;
  
    orders:Order;
    password:string;
  
    
   /* constructor(custId:string,emailId:string,firstName:string,lastName:string,isValid:string,address:string,phoneNo:string,walletBalance:number,cartItems:[],wishItems:[])
    {
        this.custId=custId;
        this.emailId=emailId;
        this.firstName=firstName;
        this.lastName=lastName;
        this.isValid=isValid;
        this.address=address;
        this.phoneNo=phoneNo;
        this.walletBalance=walletBalance;
        this.cartItems=cartItems;
        this.wishItems=wishItems;
    }
    */
}
