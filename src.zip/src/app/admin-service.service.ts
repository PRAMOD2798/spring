import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Customer } from './Customer';
import { Merchant } from './Merchant';

import { ThirdParty } from './third-party';
import { DiscountCode } from './coupon';
import { OrderedItem } from './ordered-item';
import { Product } from './Product';
import { Order } from './order';




@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  customer:Customer[];
  merchant:Merchant[];
  
  private fromAdminDD=false;
  private fromAdminTP=false;
  private inviteTP=false;
  
  private baseUrl='http://localhost:8081/ecommerce/';
  constructor(private http:HttpClient) { }
 
  
  public display(): Observable<Order>
    {
      return this.http.get<Order>(this.baseUrl + '186125/getOrderedItems')
    }
    public displayOrderedItems(): Observable<OrderedItem[]>
    {
      return this.http.get<OrderedItem[]>(this.baseUrl + '186125/getOrderedItems')
    }


  
  
  showCustomers():Observable<Customer[]>{
    console.log("http://localhost:8081/ecommerce/185755/showCust");
    return this.http.get<Customer[]>(this.baseUrl+"185755/showCust");
  }

  showMerchants():Observable<Merchant[]>{
    console.log("http://localhost:8081/ecommerce/185755/showMerch");
    return this.http.get<Merchant[]>(this.baseUrl+"185755/showMerch");
  }

  pendingRequests():Observable<Merchant[]>{
   
    console.log("http://localhost:9090/admin/");
    return this.http.get<Merchant[]>(this.baseUrl+"/pendingMerchants");
  }

  changeStatus(merchantId:number,status:string):Observable<any>{
    console.log(merchantId);
    return this.http.post<any>(this.baseUrl+"/changeStatus/",{
     "merchantId":merchantId,
     "status":status
     })

   
  }

  

  totalRevenue():Observable<number>{
    console.log(this.baseUrl+"185738/totalRevenue");
    return this.http.get<number>(this.baseUrl+"185738/totalRevenue");
  }
  public addMerchant(merchant:Merchant) :Observable<Merchant>{
    return this.http.post<Merchant>(this.baseUrl+'185697/registerMerchant/',merchant);

  };
  public deleteMerchant(merId:string) {
    return this.http.delete<Merchant>(this.baseUrl+'185697/deletemerchant/'+ merId);

  };
 
 
  public getAllCoupons():Observable<any[]>{

   return this.http.get<any[]>(this.baseUrl+"185753/getCoupon");
  }


  public generateCoupon(discountcode:DiscountCode):Observable<DiscountCode>{
  
    return  this.http.post<DiscountCode>(this.baseUrl+"185753/generateCoupon",discountcode)
   }
   showAllOrderedProducts():Observable<OrderedItem[]>
  {
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/PLD/DISP");
  }

  getProducts():Observable<OrderedItem[]>{
    
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/DISP/PLD");
  }

  //Purpose:This is for Displaying all placed  products
  showPlacedProducts():Observable<OrderedItem[]>
  {
   
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/placedproducts");
  }

  //Purpose:This is for Displaying all dispatched products
  showDispatchedProducts():Observable<OrderedItem[]>
  {
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/dispatchedproducts");
  }
  //Purpose:This is for updating placed  product to dispatched product
  updatePld(productOrdId: string,productOrdStatus: string):Observable<OrderedItem[]>{
    
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/updatePlacedProducts/"+  productOrdId + '/' + productOrdStatus);
  }
  
  //Purpose:This is for updating dispatched product to received product
  updateDisp(productOrdId: string,productOrdStatus: string):Observable<OrderedItem[]>{
    
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/updateDispatchedProducts/"+  productOrdId + '/' + productOrdStatus);
  }

  updateProduct(productOrdId: string,productOrdStatus: string):Observable<OrderedItem[]>{
  
    return this.http.get<OrderedItem[]>(this.baseUrl+"185684/updateProduct/"+  productOrdId + '/' + productOrdStatus);
  }

      





 showInventory(merchantId):Observable<Product[]>
 {
 return this.http.get<Product[]>("http://localhost:8081/api/prodcuts/"+merchantId);
 }

 showProducts():Observable<Product[]>
 {
 return this.http.get<Product[]>("http://localhost:8081/api/prodcuts/");
 }

 refund(id):Observable<Order>{
  console.log("http://localhost:8081//ecommerce/185756/refundMoney/"+id);
  return this.http.get<Order>("http://localhost:8081//ecommerce/185756/refundMoney/"+id);
}
save(order:Order):Observable<any>{
  return this.http.post<Order>(this.baseUrl+'185697/registerMerchant/',order);
}

}
