import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import { HighchartsChartModule } from 'highcharts-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowMerchantsComponent } from './show-merchants/show-merchants.component';
import { ShowInventoryComponent } from './show-inventory/show-inventory.component';
import { ShowCustomersComponent } from './show-customers/show-customers.component';

import { HttpClientModule } from '@angular/common/http';
import { PendingRequestsComponent } from './pending-requests/pending-requests.component';
import { TotalRevenueComponent } from './total-revenue/total-revenue.component';
import { AdminLoginComponent } from './adminloginpage/adminlogin.component';

import { AdminpageComponent } from './adminpage/adminpage.component';

import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { RemoveMerchantComponent } from './remove-merchant/remove-merchant.component';


import { ReportComponent } from './report/report.component';
import { FormsModule } from '@angular/forms';
import { SearchPipe } from './search.pipe';
import { MerchantsearchPipe } from './merchantsearch.pipe';
import { CategoryPipe } from './category.pipe';
import { ViewCouponsComponent } from './view-coupons/view-coupons.component';
import { CouponGenerationComponent } from './coupon-generation/coupon-generation.component';

import { OrderedProductsComponent } from './ordered-products/ordered-products.component';
import { PlacedProductsComponent } from './placed-products/placed-products.component';
import { DispatchedProductsComponent } from './dispatched-products/dispatched-products.component';
import { DeliveryStatusComponent } from './delivery-status/delivery-status.component';
import { RefundComponent } from './refund/refund.component';
import { SignUpMerchantComponent } from './add-merchant/add-merchant.component';
import { ShowProductComponent } from './show-products/show-products-component';


@NgModule({
  declarations: [
    AppComponent,
    ShowMerchantsComponent,
    ShowInventoryComponent,
    ShowCustomersComponent,
    PendingRequestsComponent,
    TotalRevenueComponent,
    AdminLoginComponent,
    AdminpageComponent,
    
    ManageMerchantComponent,
    RemoveMerchantComponent,
    SignUpMerchantComponent,
    
    ReportComponent,
    SearchPipe,
    MerchantsearchPipe,
    CategoryPipe,
    ViewCouponsComponent,
    CouponGenerationComponent,
    OrderedProductsComponent,

    PlacedProductsComponent,

    DispatchedProductsComponent,

    DeliveryStatusComponent,

    RefundComponent,
    ShowProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
     FormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
