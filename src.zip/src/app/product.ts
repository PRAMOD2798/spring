import { Merchant } from "./merchant";

export class Product {

    productId:number;
    name:string;
    brand:string;
    price:number;
    imageUrl:string;
    category:string;
    description:string;
    productType:string;
    merchant: Merchant;
    discountPercentage:number;
    viewCount:number;
    quantity:number;
   
}