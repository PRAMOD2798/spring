package com.cg.capstore.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.Admin;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.DiscountCode;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Product;
import com.cg.capstore.service.CapStoreServiceImpl;

@CrossOrigin
@RestController
@RequestMapping(value = "/capstore/admin")
public class AdminController {
	@Autowired
	private CapStoreServiceImpl service;
	
	@GetMapping
	Map<String, Object> get() {
		Map<String, Object> map= new HashMap<>();
		
		List ints = new ArrayList();
		ints.add(1);
		ints.add(2);
		ints.add(8);
		
		map.put("integers", ints);
		map.put("string", "This is a string");
		
		return map;
	}
	
	@PostMapping(value = "/addCustomer")
	public void addCustomer(@RequestHeader("authToken") String token, @RequestBody Customer customer) {
		service.addCustomer(token, customer);
	}

	@PostMapping(value = "/addAdmin")
	public void addAdmin(@RequestHeader("authToken") String token, @RequestBody Admin admin) throws Exception {
		service.addAdmin(token, admin);
	}
	
	@GetMapping(value = "/getMerchant/{id}")
	public Merchant getMerchant(@RequestHeader("authToken") String token, @PathVariable long id) throws Exception {
		return service.getMerchant(token, id);
	}
	
	@PostMapping(value = "/loginAdmin")
	public String loginAdmin(@RequestBody Admin admin) throws Exception {
		return service.loginAdmin(admin);
	}

	@PostMapping(value = "/addMerchant")
	public void addMerchant(String token, @RequestBody Merchant merchant) throws Exception {
		service.addMerchant(token, merchant);
	}

	@GetMapping(value = "/removeMerchant/{id}")
	public void removeMerchant(@RequestHeader("authToken") String token, @PathVariable(name = "id") long id) throws Exception {
		Merchant m = new Merchant();
		m.setMerchantId(id);
		service.removeMerchant(token, m);
	}

	@GetMapping(value = "/getAllProduct")
	public List<Product> getAllProduct(@RequestHeader("authToken") String token) throws Exception {
		return service.getAllProduct(token);
	}

	@GetMapping(value = "/getAllMerchantProduct/{id}")
	public List<Product> getAllMerchantProduct(@RequestHeader("authToken") String token, @PathVariable(name = "id") long id) throws Exception {
		Merchant m = new Merchant();
		m.setMerchantId(id);
		return service.getAllMerchantProduct(token, m);
	}
	
	@GetMapping(value = "/getPendingMerchant")
	public List<Merchant> getAllMerchantProduct(@RequestHeader("authToken") String token) throws Exception {
		return service.getPendingMerchant(token);
	}
	
	@PostMapping(value = "/generateCoupon")
	public DiscountCode generateCoupon(@RequestHeader("authToken") String token, @RequestBody DiscountCode code) throws Exception {
		return service.generateCoupon(token, code);
	}
	
	@PostMapping(value = "/changeMerchantStatus")
	public void changeMerchantStatus(@RequestHeader("authToken") String token, @RequestBody Merchant merchant) throws Exception {
		service.changeMerchantStatus(token, merchant);
	}
	
	@GetMapping(value = "/getCustomer/{id}")
	public Customer getCustomer(@RequestHeader("authToken") String token, @PathVariable(name = "id") long id) throws Exception {
		return service.getCustomer(token, id);
		
	}
}
