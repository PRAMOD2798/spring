package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.Admin;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.DiscountCode;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Product;

public interface CapStoreService {
	public void addCustomer(String token, Customer customer);

	public void addAdmin(String token, Admin admin) throws Exception;
	
	public String loginAdmin(Admin admin) throws Exception;

	public void addMerchant(String token, Merchant merchant) throws Exception;
	
	public Merchant getMerchant(String token, long id) throws Exception;

	public void removeMerchant(String token, Merchant merchant) throws Exception;

	public List<Product> getAllProduct(String token) throws Exception;

	public List<Product> getAllMerchantProduct(String token, Merchant merchant) throws Exception;
	
	public DiscountCode generateCoupon(String token, DiscountCode code) throws Exception;

	public void changeMerchantStatus(String token, Merchant merchant) throws Exception;
	
	public List<Merchant> getPendingMerchant(String token) throws Exception;
	
	public Customer getCustomer(String token, long id) throws Exception;
}
