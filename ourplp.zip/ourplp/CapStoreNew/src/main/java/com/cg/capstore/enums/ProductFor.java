package com.cg.capstore.enums;

public enum ProductFor {
	MEN, WOMEN, KIDS, GENERAL
}