package com.cg.capstore.enums;

public enum Gender {
	MALE, FEMALE, OTHER
}
