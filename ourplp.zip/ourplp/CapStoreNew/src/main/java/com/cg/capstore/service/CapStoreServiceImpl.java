package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CapStoreDaoImpl;
import com.cg.capstore.entity.Admin;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.DiscountCode;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Product;

@Service
public class CapStoreServiceImpl implements CapStoreService {

	@Autowired
	private CapStoreDaoImpl dao;
	
	@Override
	public void addCustomer(String token, Customer customer) {
		dao.createCustomer(token, customer);
	}

	@Override
	public void addAdmin(String token, Admin admin) throws Exception {
		dao.createAdmin(token, admin);
	}

	@Override
	public void addMerchant(String token, Merchant merchant) throws Exception {
		dao.createMerchant(token, merchant);
	}

	@Override
	public void removeMerchant(String token, Merchant merchant) throws Exception {
		dao.deleteMerchant(token, merchant);
	}

	@Override
	public List<Product> getAllProduct(String token) throws Exception {
		return dao.readAllProduct(token);
	}

	@Override
	public List<Product> getAllMerchantProduct(String token, Merchant merchant) throws Exception {
		return dao.readAllMerchantProduct(token, merchant);
	}

	@Override
	public DiscountCode generateCoupon(String token, DiscountCode code) throws Exception {
		return dao.createCoupons(token, code);
	}

	@Override
	public String loginAdmin(Admin admin) throws Exception {
		return dao.loginAdmin(admin);
	}
	
	@Override
	public void changeMerchantStatus(String token, Merchant merchant) throws Exception {
		dao.updateMerchantStatus(token, merchant);
	}

	@Override
	public Merchant getMerchant(String token, long id) throws Exception {
		return dao.readMerchant(token, id);
	}
	
	@Override
	public List<Merchant> getPendingMerchant(String token) throws Exception {
		return dao.readPendingMerchant(token);
	}
	
	@Override
	public Customer getCustomer(String token, long id) throws Exception {
		return dao.readCustomer(token, id);
	}
}
