package com.cg.capstore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.capstore.enums.MerchantStatus;

@Entity
@Table(name = "merchant")
public class Merchant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long merchantId;
	
	String token;

	String merchantName;
	
	@OneToOne(cascade = CascadeType.ALL)
	Address address;

	@Column(unique = true)
	long mobileNumber;

	@Column(unique = true)
	String email;

	String password;

	String shopName;

	String securityQuestion;

	String answer;

	@OneToMany(cascade=CascadeType.ALL, mappedBy = "merchant")
	List<Product> products = new ArrayList<Product>();

	@OneToMany
	List<OrderItem> items = new ArrayList<OrderItem>();

	MerchantStatus status;
	
	double commissionPercent;
	
	public double getCommissionPercent() {
		return commissionPercent;
	}

	public void setCommissionPercent(double commissionPercent) {
		this.commissionPercent = commissionPercent;
	}

	public long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public List<OrderItem> getItems() {
		return items;
	}

	public void setItems(List<OrderItem> items) {
		this.items = items;
	}

	public MerchantStatus getStatus() {
		return status;
	}

	public void setStatus(MerchantStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", token=" + token + ", merchantName=" + merchantName
				+ ", address=" + address + ", mobileNumber=" + mobileNumber + ", email=" + email + ", password="
				+ password + ", shopName=" + shopName + ", securityQuestion=" + securityQuestion + ", answer=" + answer
				+ ", products=" + products + ", items=" + items + ", status=" + status + "]";
	}
	
}
