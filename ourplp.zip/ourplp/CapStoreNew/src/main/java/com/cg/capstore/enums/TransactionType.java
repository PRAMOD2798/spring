package com.cg.capstore.enums;

public enum TransactionType {
	DEBIT, CREDIT
}
