package com.cg.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.capstore.entity.Admin;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.DiscountCode;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Product;
import com.cg.capstore.enums.Gender;
import com.cg.capstore.enums.MerchantStatus;
import com.cg.wallet.util.JPAUtil;
import com.cg.wallet.util.PasswordEncryption;

@Repository
public class CapStoreDaoImpl implements CapStoreDao {

	private static EntityManager em = JPAUtil.getEntityManager();

	static {
		try {
			// Create Customer
			Customer c = new Customer();
			c.setEmail("cust@gmail.com");
			c.setCustomerName("ayush");
			c.setPassword("cust");
			c.setMobileNo(7777776543L);
			c.setGender(Gender.MALE);
			
			
			// Create Merchant and add products in it
			
			// Denied Merchant
			Merchant m = new Merchant();
			m.setEmail("merch@gmail.com");
			m.setMerchantName("XI");
			m.setPassword("merch");
			m.setMobileNumber(8898900000L);
			m.setShopName("Mobi Store");
			m.setStatus(MerchantStatus.FAILED);
			
			
			// Pending Merchant
			Merchant m0 = new Merchant();
			m0.setMerchantName("balram");
			m0.setEmail("merchant0@gmail.com");
			m0.setPassword("merchant");
			m0.setMobileNumber(8898987767L);
			m0.setShopName("Mobi Store 0");
			m0.setStatus(MerchantStatus.PENDING);
			
			
			// Approved Merchant
			Merchant m1 = new Merchant();
			m1.setEmail("merchant1@gmail.com");
			m1.setMerchantName("sourav");
			m1.setPassword("merchant");
			m1.setMobileNumber(8898987711L);
			m1.setShopName("Mobi Store 1");
			m1.setStatus(MerchantStatus.APPROVED);

			Merchant m2 = new Merchant();
			m2.setEmail("merchant2@gmail.com");
			m2.setMerchantName("Rishav");
			m2.setPassword("merchant");
			m2.setMobileNumber(8765432100L);
			m2.setShopName("General Store 2");
			m2.setStatus(MerchantStatus.APPROVED);

			Product p1 = new Product();
			p1.setName("Soap");
			p1.setBrand("Lux");
			p1.setPrice(35.11);
			p1.setMerchant(m1);

			Product p2 = new Product();
			p2.setName("Tea");
			p2.setBrand("Red Label");
			p2.setPrice(200);
			p2.setMerchant(m1);

			Product p3 = new Product();
			p3.setName("Pen");
			p3.setBrand("Red Label");
			p3.setPrice(200);
			p3.setMerchant(m2);

			m1.getProducts().add(p1);
			m1.getProducts().add(p2);
			m2.getProducts().add(p3);

			// Create admin
			Admin admin = new Admin();
			admin.setEmail("admin@gmail.com");
			admin.setPassword(PasswordEncryption.encrypt("admin"));
			admin.setMobileNumber(9999999999L);
			admin.setSecurityQuestion("What's my dog name?");
			admin.setAnswer("golu");

			// Save to DB
			em.getTransaction().begin();
			em.persist(m);
			em.persist(m0);
			em.persist(m1);
			em.persist(m2);
			em.persist(admin);
			em.persist(c);
			em.getTransaction().commit();
			
			

		} catch (Exception e) {
//			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

	public void createAdmin(String token, Admin admin) throws Exception {
//		authenticateAdmin(token);

		admin.setPassword(PasswordEncryption.encrypt(admin.getPassword()));
		admin.setAnswer(PasswordEncryption.encrypt(admin.getAnswer()));

		try {
			beginTransaction();
			em.persist(admin);
			commitTransaction();
		} catch (EntityExistsException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new Exception("Email or Mobile number already in use");
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			
		}

	}

	public void createMerchant(String token, Merchant merchant) throws Exception {
//		authenticateAdmin(token);

		merchant.setPassword(PasswordEncryption.encrypt(merchant.getPassword()));
		merchant.setAnswer(PasswordEncryption.encrypt(merchant.getAnswer()));

		try {
			beginTransaction();
			em.persist(merchant);
			commitTransaction();
		} catch (EntityExistsException e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new Exception("Email or Mobile number already in use");
		} catch (Exception e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}		}
	}

	public void deleteMerchant(String token, Merchant merchant) throws Exception {
//		authenticateAdmin(token);

		try {
			beginTransaction();
			em.merge(merchant);
			em.remove(merchant);
			commitTransaction();
		} catch (EntityExistsException e) {
			em.getTransaction().rollback();
			throw new Exception("Email or Mobile number already in use");
		} catch (Exception e) {
			em.getTransaction().rollback();
		}
	}
	
	public List<Product> readAllProduct(String token) throws Exception {
//		authenticateAdmin(token);

		try {
			TypedQuery<Product> query = em.createQuery("FROM Product", Product.class);
			List<Product> list = query.getResultList();

			// Restrict Association
			if (!list.isEmpty()) {
				list.forEach(product -> {
					product.getMerchant().getProducts().clear();
				});
			}

			return list;

		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new Exception("Technical issue:" + e.getMessage());
		}

	}

	public List<Product> readAllMerchantProduct(String token, Merchant merchant) throws Exception {
//		authenticateAdmin(token);

		try {
			TypedQuery<Merchant> query = em.createQuery("FROM Merchant m WHERE m.merchantId=:id", Merchant.class);
			query.setParameter("id", merchant.getMerchantId());

			List<Merchant> merchants = query.getResultList();
			if (!merchants.isEmpty()) {
				List<Product> products = merchants.get(0).getProducts();
				if (!products.isEmpty()) {
					products.forEach(product -> {
						products.forEach(p -> p.setMerchant(null));
					});
				}
				return products;
			}
			return new ArrayList<Product>();

		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}

			throw new Exception("Technical issue:" + e.getMessage());
		}

	}

	@Override
	public DiscountCode createCoupons(String token, DiscountCode coupon) throws Exception {
//		authenticateAdmin(token);

		try {
			boolean isCouponExist = true;

			while (isCouponExist) {
				String name = "C" + getAlphaNumericString(7);
				TypedQuery<DiscountCode> query = em.createQuery("SELECT d FROM DiscountCode d WHERE d.name=:name",
						DiscountCode.class);
				
				query.setParameter("name", name);

				List list = query.getResultList();
				
				System.out.println("Dis: " + list);
				if (list.isEmpty()) {
					coupon.setName(name);
					isCouponExist = false;
					System.out.println("Code: " + coupon);
					beginTransaction();
					em.persist(coupon);
					commitTransaction();
				}
			}
			return coupon;
		} catch (Exception e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new Exception("Technical issue:" + e.getMessage());
		}

	}

	private String getAlphaNumericString(int n) {
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			int index = (int) (AlphaNumericString.length() * Math.random());

			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	@Override
	public Admin authenticateAdmin(String token) throws Exception {
		if (token == null) {
			throw new Exception("Please Login First");
		}
		TypedQuery<Admin> query = em.createQuery("FROM Admin a where a.authToken=:token", Admin.class);
		query.setParameter("token", token);
		List<Admin> list = query.getResultList();
		if (list.isEmpty() || list == null) {
			throw new Exception("Please Login First");
		}
		return list.get(0);
	}

	public String loginAdmin(Admin admin) throws Exception {

		try {
			admin.setPassword(PasswordEncryption.encrypt(admin.getPassword()));

			TypedQuery<Admin> query = em
					.createQuery("SELECT a FROM Admin a where a.email=:email AND a.password=:password", Admin.class);
			query.setParameter("email", admin.getEmail());
			query.setParameter("password", admin.getPassword());
			List<Admin> list = query.getResultList();

			if (list.isEmpty()) {
				throw new Exception("Authentication failed");
			}

			admin = list.get(0);
			admin.setAuthToken(generateAuthToken());

			beginTransaction();
			em.persist(admin);
			commitTransaction();

			return admin.getAuthToken();

		} catch (Exception e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new Exception("Technical issue:" + e.getMessage());
		}

	}

	public void commitTransaction() {
		em.getTransaction().commit();
	}

	public void beginTransaction() {
		em.getTransaction().begin();

	}

	@Override
	public void createCustomer(String token, Customer customer) {
		// TODO Auto-generated method stub
	}

	private static String generateAuthToken() {
		int n = 35;
		// chose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	@Override
	public void updateMerchantStatus(String token, Merchant merchant) throws Exception {
//		authenticateAdmin(token);

		try {
			beginTransaction();
			em.merge(merchant);
			commitTransaction();
		} catch (EntityExistsException e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new Exception("Email or Mobile number already in use");
		} catch (Exception e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
		}
	}
	
	public Customer readCustomer(String token, long id) throws Exception {
//		authenticateAdmin(token);
		try {
			return em.find(Customer.class, id);
		} catch (Exception e) {
			throw new Exception("Technical issue:" + e.getMessage());
		}
	}
	
	public List<Merchant> readPendingMerchant(String token) throws Exception {
//		authenticateAdmin(token);

		try {
			
			TypedQuery<Merchant> query = em.createQuery("FROM Merchant m WHERE m.status=:status", Merchant.class);
			query.setParameter("status", MerchantStatus.PENDING);
			return query.getResultList();
		} catch (Exception e) {
			throw new Exception("Technical issue:" + e.getMessage());
		}
	}

	@Override
	public Merchant readMerchant(String token, long id) throws Exception {
//		authenticateAdmin(token);

		try {
			Merchant m = em.find(Merchant.class, id);
			m.setProducts(null);
			m.setItems(null);
			m.setPassword(null);
			return m;
		} catch (Exception e) {
			if(em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new Exception("Technical issue:" + e.getMessage());
		}

	}

}
