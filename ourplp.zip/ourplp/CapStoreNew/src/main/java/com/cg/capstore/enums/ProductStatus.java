package com.cg.capstore.enums;

public enum ProductStatus {
	PLACED, IN_TRANSIT,DELIVERED,RETURN_PENDING,RETURNED
}
