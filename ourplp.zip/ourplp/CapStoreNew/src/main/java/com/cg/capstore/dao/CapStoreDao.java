package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.entity.Admin;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.DiscountCode;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Product;

public interface CapStoreDao {
	
	public void createCustomer(String token, Customer customer);
	
	public void createAdmin(String token, Admin admin) throws Exception;
	
	public void createMerchant(String token, Merchant merchant) throws Exception;
	
	public void deleteMerchant(String token, Merchant merchant) throws Exception;
	
	public List<Product> readAllProduct(String token) throws Exception;
	
	public List<Product> readAllMerchantProduct(String token, Merchant merchant) throws Exception;
	
	public Admin authenticateAdmin(String token) throws Exception;
	
	public DiscountCode createCoupons(String token, DiscountCode coupon) throws Exception;
	
	public void updateMerchantStatus(String token, Merchant merchant) throws Exception;

	public Customer readCustomer(String token, long id) throws Exception;
	
	public Merchant readMerchant(String token, long id) throws Exception;
	
	public List<Merchant> readPendingMerchant(String token) throws Exception;
	
	public String loginAdmin(Admin admin) throws Exception;
	
	public void commitTransaction();

	public void beginTransaction();
}
