package com.cg.capstore.enums;

public enum AddressType {
	HOME, OFFICE
}
