package com.cg.capstore.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class CartItems {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long cartId;
	
	@ManyToOne
	Product product;
	
	int cartQuantity;

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getCartQuantity() {
		return cartQuantity;
	}

	public void setCartQuantity(int cartQuantity) {
		this.cartQuantity = cartQuantity;
	}

	@Override
	public String toString() {
		return "CartItems [cartId=" + cartId + ", product=" + product + ", cartQuantity=" + cartQuantity + "]";
	}

}
