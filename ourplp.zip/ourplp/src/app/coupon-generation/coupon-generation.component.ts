import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import {DiscountCode } from '../coupon';

@Component({
  selector: 'app-coupon-generation',
  templateUrl: './coupon-generation.component.html',
  styleUrls: ['./coupon-generation.component.css']
})
export class CouponGenerationComponent implements OnInit {

 discountcode:DiscountCode; 
 flag1:boolean=false;
 flag2:boolean=false;
 disccodelist:DiscountCode[]; 
  constructor(private adminService:AdminServiceService) { }

  generate(){
    this.flag1=true;
    this.flag2=false;
  }

  view(){
    this.flag2=true;
    this.flag1=false;
    this.adminService.getAllCoupons().subscribe(data=>this.responseData(data))
  }

  responseData(response){
    this.disccodelist=response;
    console.log(this.disccodelist)
  }

generateCoupon(value:number,minimumAmount:number){
  console.log(value)
  this.discountcode=new DiscountCode();
  this.discountcode.value = value
  this.discountcode.minimumAmount  = minimumAmount
  this.adminService.generateCoupon(this.discountcode).subscribe();
}

  ngOnInit() {
  }

}
