import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-adminloginpage',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminLoginComponent implements OnInit {
  username:string;
  password:string;
  


  constructor(private router: Router, private httpClientService: AdminServiceService) { 
  
    
  }

  ngOnInit() {
  }

  login(username,password)
  {
    if(username=="Admin" && password=="admin123"){
      this.router.navigate(["/adminpage"])
    }
    else{
      alert("Enter valid credentials");
    }
    
  }

  

}

/*
login(event, username, password) {
  event.preventDefault();
  var success = this.loginService.login(username, password);
  if (success) {
    console.log(this.router);
    this.router.navigate(['']);
  } else {
    console.log("Login failed, display error to user");
  }*/
