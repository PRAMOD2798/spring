import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowCustomersComponent } from './show-customers/show-customers.component';
import { ShowMerchantsComponent } from './show-merchants/show-merchants.component';
import { ShowInventoryComponent } from './show-inventory/show-inventory.component';

import { PendingRequestsComponent } from './pending-requests/pending-requests.component';
import { TotalRevenueComponent } from './total-revenue/total-revenue.component';

import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { RemoveMerchantComponent } from './remove-merchant/remove-merchant.component';

import { ReportComponent } from './report/report.component';

import { CouponGenerationComponent } from './coupon-generation/coupon-generation.component';
import { ViewCouponsComponent } from './view-coupons/view-coupons.component';
import { DeliveryStatusComponent } from './delivery-status/delivery-status.component';


import { DispatchedProductsComponent } from './dispatched-products/dispatched-products.component';
import { RefundComponent } from './refund/refund.component';
import { SignUpMerchantComponent } from './add-merchant/add-merchant.component';
import { ShowProductComponent } from './show-products/show-products-component';
import { AdminLoginComponent } from './adminloginpage/adminlogin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';

const routes: Routes = [

  {
    path:"",redirectTo:"/loginadmin",
    pathMatch:"full"

  },
  {
    path:'loginadmin',
    component:AdminLoginComponent
  },
  
  {
    path:'showCust',
    component:ShowCustomersComponent
  },
  {
    path:'showMerch',
    component:ShowMerchantsComponent
  },
  {
    path:'manageMerch',
    component:ManageMerchantComponent
  },
  {
    path:'showInven',
    component:ShowInventoryComponent
  },
 
  {
    path:'pendingReq',
    component:PendingRequestsComponent
  },
  {
    path:'totalRev',
    component:TotalRevenueComponent
  },
 
  
  {
    path: 'delete',
    component: RemoveMerchantComponent
  },
  {
    path: 'register',
    component: SignUpMerchantComponent
  },
  {
    path:'manageMerch',
    component:ManageMerchantComponent
  },
  

  
  {
    path:'refund',
    component:RefundComponent
  },
  {
    path:'report',
    component:ReportComponent
  },
  
  {
    path:'generate',
    component:CouponGenerationComponent
  },
  {
    path:'viewCoupons',
    component:ViewCouponsComponent
  },
  
  
 
  {
    path:'dispatchedProducts',
    component:DispatchedProductsComponent
  },
  
  {
    path:'deliveryStatus',
    component:DeliveryStatusComponent
  },
  {
    path:'showProducts',
    component:ShowProductComponent
  },

  {
    path:'adminpage',
    component:AdminpageComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
