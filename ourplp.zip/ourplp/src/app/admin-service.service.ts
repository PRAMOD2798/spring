import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Customer } from './Customer';
import { Merchant } from './Merchant';

import { ThirdParty } from './third-party';
import { DiscountCode } from './coupon';
import { OrderedItem } from './ordered-item';
import { Product } from './Product';
import { Order } from './order';




@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  customer: Customer[];
  merchant: Merchant[];

  private fromAdminDD = false;
  private fromAdminTP = false;
  private inviteTP = false;

  private baseUrl = 'http://localhost:9090/capstore/admin/';
  constructor(private http: HttpClient) { }


  public display(): Observable<Order> {
    return this.http.get<Order>(this.baseUrl + '/getOrder')
  }




  showCustomer(customerId: number): Observable<Customer> {

    return this.http.get<Customer>(this.baseUrl + "getCustomer/" + customerId, {headers: { "authToken": "erfbbuyjhujio" }});
  }

  showMerchant(merchantId: number): Observable<Merchant> {
    console.log(merchantId)
    return this.http.get<Merchant>(this.baseUrl + "getMerchant/" + merchantId, {
      headers: { "authToken": "erfbbuyjhujio" }
    });
  }

  pendingRequests(): Observable<Merchant[]> {


    return this.http.get<Merchant[]>(this.baseUrl + "getPendingMerchant", {headers: { "authToken": "erfbbuyjhujio" }});
  }

  changeStatus(merchant: Merchant): Observable<any> {

    return this.http.post<any>(this.baseUrl + "changeMerchantStatus", {
      "merchantId": merchant.merchantId,
      "status": merchant.status
    },  {headers: { "authToken": "erfbbuyjhujio" }})


  }



  totalRevenue(): Observable<number> {
    console.log(this.baseUrl + "/totalRevenue");
    return this.http.get<number>(this.baseUrl + "/totalRevenue", {headers: { "authToken": "erfbbuyjhujio" }});
  }

  public addMerchant(merchant: Merchant): Observable<Merchant> {
    console.log(merchant)
    return this.http.post<Merchant>(this.baseUrl + "addMerchant", merchant, {headers: { "authToken": "erfbbuyjhujio" }});

  };
  public deleteMerchant(merchantid: number) {
    return this.http.delete<Merchant>(this.baseUrl + "removeMerchant/" + merchantid, {headers: { "authToken": "erfbbuyjhujio" }});

  };


  public getAllCoupons(): Observable<any[]> {

    return this.http.get<any[]>(this.baseUrl + "getCoupon");
  }


  public generateCoupon(discountcode: DiscountCode): Observable<DiscountCode> {
    console.log(discountcode)
    return this.http.post<DiscountCode>(this.baseUrl + "generateCoupon", discountcode, {
      headers: { "authToken": "erfbbuyjhujio" }
    })


  }






  //Purpose:This is for Displaying all dispatched products
  showDispatchedProducts(): Observable<OrderedItem[]> {
    return this.http.get<OrderedItem[]>(this.baseUrl + "/dispatchedproducts");
  }


  //Purpose:This is for updating placed  product to dispatched product
  updatePld(productOrdId: string, productOrdStatus: string): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "/updatePlacedProducts/" + productOrdId + '/' + productOrdStatus);
  }

  //Purpose:This is for updating dispatched product to received product
  updateDisp(productOrdId: string, productOrdStatus: string): Observable<OrderedItem[]> {

    return this.http.get<OrderedItem[]>(this.baseUrl + "/updateDispatchedProducts/" + productOrdId + '/' + productOrdStatus);
  }



  showInventory(merchantId): Observable<Product[]> {
    return this.http.get<Product[]>("/" + merchantId);
  }

  showProducts(): Observable<Product[]> {
    return this.http.get<Product[]>("/");
  }

  refund(id): Observable<Order> {

    return this.http.get<Order>("/" + id);
  }

  save(order: Order): Observable<any> {
    return this.http.post<Order>(this.baseUrl + '185697/registerMerchant/', order, {
      headers: {
        "authToken": "erfbbuyjhujio"
      }
    });
  }

}
