import { Component, OnInit } from '@angular/core';
import { Merchant } from '../Merchant';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-show-merchants',
  templateUrl: './show-merchants.component.html',
  styleUrls: ['./show-merchants.component.css']
})
export class ShowMerchantsComponent  {
  

  merchant:Merchant;
  status:boolean=false;
  merchantId:number;
  

  constructor( private httpClientService:AdminServiceService) { }

  onSubmit() {
    
       this.httpClientService.showMerchant(this.merchantId).subscribe(
        data =>{this.merchant = data;}
        );
     this.status=true;
}

}
