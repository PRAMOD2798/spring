import { Customer } from './customer';
import { Product } from './product';
import { Merchant } from './merchant';
import { Transaction } from './transaction';
import { DiscountCode } from './coupon';
import { Order } from './order';

export class OrderedItem {

    id:number;
    quantity:number;
    paidAmount:number;
    promoCode:number;
    couponCode:string;
    deliveryDate:string;
    customer:Customer
     product:Product;
     order:Order;
     status:string;
}
