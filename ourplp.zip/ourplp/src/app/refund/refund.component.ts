import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Order } from '../order';
import { OrderedItem } from '../ordered-item';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.css']
})
export class RefundComponent implements OnInit {
  order:Order;
  orderItems:OrderedItem[];
  result:boolean;
  totalPrice=0;
  selectedStatus:string;
  
  flag:boolean=false;
  

  constructor(private router: Router, private adminService:AdminServiceService) {
    
   
  
   }

  

   ngOnInit() {
    
  }
  refund(id)
  {
    this.adminService.refund(id).subscribe(
      data=>{
       
        this.order=data;
        this.orderItems=this.order.items;
        this.orderItems.forEach(element => {
          this.totalPrice+=element.paidAmount;
         // element.status=this.selectedStatus;
        });
        this.order.items
        this.flag=true;

        
      });
  }

  onChange(newValue) {

    this.orderItems.forEach(element => {
      element.status=this.selectedStatus;
    })
   
  }

  save(){
    this.order.items=this.orderItems;
    this.adminService.save(this.order).subscribe(data=> this.result=data)
      if(this.result){
      alert("Refund Successfully")
      }
      else{
        alert("There is some issue..")
      }
    }

  
    
  
  }


