import { Address } from './address';

export class Merchant {

    merchantId:number;
    token:string;
    merchantName:string;
    address:Address;
    mobileNumber:number;
    email:string;
    shopName:string;
    products:[];
    password:string;
    status:string;
    commissionPercent:number;
  
}
