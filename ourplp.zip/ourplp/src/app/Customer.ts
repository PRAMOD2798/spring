import { Product } from './product';
import { Address } from './address';
import { CartItems } from './cartItems';
import { Order } from './order';
import { Gender } from './Gender';

export class Customer {

    customerId:number;
    authToken:string;
    customerName:string;
    addresses:Address;
    email:string;
    mobileNo:string;
    gender:Gender;
    wishItems:Product;
    cartItems:CartItems;
  
    orders:Order;
    password:string;
  
    
  
}
