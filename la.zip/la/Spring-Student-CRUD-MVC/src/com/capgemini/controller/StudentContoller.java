package com.capgemini.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.model.Student;
import com.capgemini.service.StudentService;

@Controller("")
public class StudentContoller {

	@Autowired
	private StudentService service;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String homepage() {
		return "index";
	}
	
	@RequestMapping(path ="add", method = RequestMethod.GET)
	public String addPage()
	{
		return "addStudent";
	}
	@RequestMapping(path ="add", method = RequestMethod.POST)
	public String addToDatabase(@RequestParam("studentId")int id,@RequestParam("studentName")String name){
		Student s=new Student();
		s.setStudentId(id);
		s.setName(name);
		service.addStudent(s);
		return "redirect:display";
		
	}

	@RequestMapping(path = "display", method = RequestMethod.GET)
	public String displayStudent(Model model) {
		List<Student> list = service.findAllStudent();
		System.out.println(list);
		model.addAttribute("listStudent",list);
		return "displaystudent";
	}
	@RequestMapping(path = "delete", method = RequestMethod.GET)
	public String deleteStudent(@RequestParam("id")int id)
	{
		Student s=new Student();
		s.setStudentId(id);
		service.removeStudent(s);
		return "redirect:display";
	}
	@RequestMapping(path = "update", method = RequestMethod.GET)

	public String updatePage(@RequestParam("id")int id,@RequestParam("name")String name,Model model)
	{
		Student s=new Student();
		s.setStudentId(id);
		s.setName(name);
		model.addAttribute("student",s);
		return "updatestudent";
		
	}
	@RequestMapping(path = "update", method = RequestMethod.POST)

	public String updateToDatabase(@RequestParam("studentId")int id,@RequestParam("studentName")String name){
		Student s=new Student();
		s.setStudentId(id);
		s.setName(name);
		service.updateStudent(s);
		return "redirect:display";
	}
}
