package com.capgemini.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cg.jdbccrud.entities.Student;
@Configuration
@ComponentScan("com.cg.jpacrud")
public class JavaConfig
{
	
	@Bean(name="student")
	@Scope(scopeName="prototype")
    public Student studentBean(){
	   Student student=new Student();
	   return student;
   }
}
