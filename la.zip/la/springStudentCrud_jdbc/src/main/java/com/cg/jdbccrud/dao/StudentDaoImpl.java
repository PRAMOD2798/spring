package com.cg.jdbccrud.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cg.jdbccrud.entities.Student;

public class StudentDaoImpl implements StudentDao {
	private JdbcTemplate jdbcTemplate;

	public StudentDaoImpl() {
		System.out.println("StudentDaoImpl() called");
	}

	public Student getStudentById(int id) {
		String query = "Select * from students where studentId=" + id;
		List<Student> list = jdbcTemplate.query(query, new StudentRowmapper());

		return list.get(0);
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void addStudent(Student student) {
		String query = "Insert into Students(StudentId,Name) Values("+ student.getStudentId() + ",'"+ student.getName() + "')";
		System.out.println(query);
		jdbcTemplate.update(query);

	}

	public void removeStudent(Student student) {
		String query = "Delete From Students where StudentId=" + student.getStudentId();
		jdbcTemplate.update(query);

	}

	public void updateStudent(Student student) {
		String query = "Update Students SET Name='" + student.getName() + "'where StudentId="
				+ student.getStudentId();
	}

	public void commitTransaction() 
	{
		
	}

	public void beginTransaction() 
	{
		
	}

}
