package com.cg.jdbccrud.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.jdbccrud.entities.Student;

public class StudentRowmapper implements RowMapper<Student> 
{

	
	public Student mapRow(ResultSet rs, int arg1) throws SQLException {
		int id=rs.getInt("studentId");
		//int id=rs.getInt(1)
		String name=rs.getString("Name");
		//String name=rs.getString(2);
		Student s= new Student();
		s.setStudentId(id);
		s.setName(name);
		return s;
	}

}
