package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capgemini.model.Trainee;

public class TraineeRowMapper implements RowMapper<Trainee> {

	@Override
	public Trainee mapRow(ResultSet rs, int rowNum) throws SQLException {
		int id = rs.getInt("traineeid");
		String name = rs.getString("name");
		String location = rs.getString("location");
		String domain = rs.getString("domain");
		Trainee trainee = new Trainee();
		trainee.setTraineeId(id);
		trainee.setTraineeName(name);
		trainee.setTraineeDomain(domain);
		trainee.setTraineeLocation(location);
		return trainee;
	}
}
