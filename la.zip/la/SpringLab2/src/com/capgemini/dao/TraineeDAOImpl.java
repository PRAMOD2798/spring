package com.capgemini.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.capgemini.model.Trainee;

@Repository
public class TraineeDAOImpl implements TraineeDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Trainee find(int TraineeId) {

		String query = "SELECT * FROM trainees WHERE traineeid=" + TraineeId;
		List<Trainee> list = jdbcTemplate.query(query, new TraineeRowMapper());
		return list.get(0);
	}

	public List<Trainee> getAll() {
		String query = "SELECT * FROM trainees";
		List<Trainee> list = jdbcTemplate.query(query, new TraineeRowMapper());
		return list;
	}

	public void create(Trainee t) {
		String query = "INSERT INTO trainees(traineeid, name, location, domain) values(" + t.getTraineeId() + ",'"
				+ t.getTraineeName() + "','" + t.getTraineeLocation() + "','" + t.getTraineeDomain() + "')";
		System.out.println(query);
		jdbcTemplate.update(query);
	}

	public void delete(Integer t) {
		String query = "DELETE FROM trainees WHERE traineeId=" + t.intValue();
		jdbcTemplate.update(query);
	}

	public void modify(Trainee t) {
		String query = "UPDATE trainees SET name='" + t.getTraineeName() + "',location='" + t.getTraineeLocation()
				+ "',domain='" + t.getTraineeDomain() + "'WHERE traineeId=" + t.getTraineeId();
		jdbcTemplate.update(query);
	}
}
