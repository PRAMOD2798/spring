import { Component } from '@angular/core';
import { UserService } from './user.service';
import { IUser } from './user';


@Component({
    selector: 'show-balance',
    templateUrl: './showBalanceComponent.html'
})

export class showBalanceComponent{
    
    user:IUser;
     balance:number;
    status:boolean=false;
    

    constructor(private userService: UserService) {
        this.user=new IUser();
    }

onSubmit() {
    
        this.userService.viewBalance(this.user.userName).subscribe(data => {
            this.balance = data;
            });
            console.log("hii");
            this.status=!this.status;
     

}}