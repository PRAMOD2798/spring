package com.capgemini.Service;
import java.util.List;

import com.capgemini.model.User1;

public interface BankService {

	
	public double showBalance(String userName);
	public double deposit(String userName,double amount);
	public double Withdraw(String userName, double amount);
	public double fundTransfer(String userName,String username1,double amount);
	 public boolean validate(String userName);
	 public boolean matchPass(String userName,String password) ;
	public void createAccount(User1 user);
	public void printTransfer();	
	public List showAllUsers();
	
	
	  
}
